using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;


public class Lokatunna : MonoBehaviour
{
    public GameObject sprenging;
    private TextMeshProUGUI countText;
    private TextMeshProUGUI texti;
    //Breyta fyrir hlj��
    public AudioSource sprengiHljod;
    void Start()
    {
        //Setur textann � breytu
        texti = GameObject.Find("Text2").GetComponent<TextMeshProUGUI>();
        countText = GameObject.Find("Text").GetComponent<TextMeshProUGUI>();
        SetCountText();
    }

    private void Update()
    {
        if (transform.position.y < -10)
        {
            Destroy(gameObject);
            gameObject.SetActive(false);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {     
        if (collision.collider.tag == "kula")
        {
            //Loadar endasenuna, n�llstillir stig og l�f
            Debug.Log("�� fannst lokatunnuna");
            SceneManager.LoadScene(2);
            Ovinur.health = 30;
            Kassi.count = 0;
            texti.text = "L�f " + Ovinur.health.ToString();
        }

    }

    public void SetCountText() //Fall til a� gefa upp Stig.
    {
        countText.text = "Stig: " + Kassi.count.ToString();
    }
    
    public void Sprengin()//Fall til a� gera sprengju
    {
        Instantiate(sprenging, transform.position, transform.rotation);
    }
}

