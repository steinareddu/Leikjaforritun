using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Tunna : MonoBehaviour
{
    public GameObject sprenging;
    private TextMeshProUGUI countText;
    public AudioSource sprengiHljod;//Sprengihlj��
    void Start()
    {
        //S�kir textann "Text" og callar � SetCountText til a� gefa upp l�f �ar.
        countText = GameObject.Find("Text").GetComponent<TextMeshProUGUI>();
        SetCountText();
    }

    private void Update()
    {
        if (transform.position.y < -10)
        {
            Destroy(gameObject);
            gameObject.SetActive(false);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "kula")//Gefur 3 stig fyrir tunnu, uppf�rir stig, sprengir og spilar hlj��
        {
            Destroy(gameObject);
            gameObject.SetActive(false);
            Debug.Log("�� fannst tunnu");
            Kassi.count = Kassi.count + 3;
            SetCountText();
            Sprengin();
            sprengiHljod.Play();
        }

    }

    public void SetCountText()//Fall til a� gefa upp Stig.
    {
        countText.text = "Stig: " + Kassi.count.ToString();
    }
    public void Sprengin()//Fall til a� gera sprengju
    {
        Instantiate(sprenging, transform.position, transform.rotation);
    }
}
