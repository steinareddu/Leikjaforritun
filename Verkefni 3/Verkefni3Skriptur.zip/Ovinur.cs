﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
//using UnityEngine.UI;
using TMPro;

public class Ovinur : MonoBehaviour
{
    public static int health = 30;
    public Transform player;
    private TextMeshProUGUI texti;
    private Rigidbody rb;
    private Vector3 movement;
    public float hradi = 5f;//Hraða breyta sem er stillanleg
    public AudioSource ovinurSound;//Breyta fyrir hljóð, þegar óvinur klessir á
    public AudioSource sprengiHljod;//Breyta fyrir sprengihljóð
    public GameObject sprenging; 
    private TextMeshProUGUI countText;
    
    void Start() //Sækir í bæði textaboxin og gefur upp byrjunarlíf og stig.
    {
        texti= GameObject.Find("Text2").GetComponent<TextMeshProUGUI>();
        rb = this.GetComponent<Rigidbody>();
        texti.text = "Líf: " + health.ToString();
        countText = GameObject.Find("Text").GetComponent<TextMeshProUGUI>();
        SetCountText();

    }

    void Update()
    {
        Vector3 stefna = player.position - transform.position;
        stefna.Normalize();
        movement = stefna;
    }
    private void FixedUpdate()
    {
        Hreyfing(movement);
    }
    void Hreyfing(Vector3 stefna)
    {
        rb.MovePosition(transform.position + (stefna * hradi * Time.deltaTime));
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag=="Player")//Tekur 10 líf, spilar óvinahljóð ef kúla nær spilara
        {
            Debug.Log("Leikmaður fær í sig óvin");
            TakeDamage(10);
            gameObject.SetActive(false);
            ovinurSound.Play();
        }
        if (collision.collider.tag == "kula")//Lætur óvin hverfa, kemur sprengja og sprengihljóð, 
        {
            Destroy(gameObject);
            gameObject.SetActive(false);
            Debug.Log("Þú drapst óvin");
            SetCountText();//kallar í aðferðina
            Sprengin();
            sprengiHljod.Play();
        }

    }
    public void TakeDamage(int damage)//Aðferð sem uppfærir líf og klárar leikinn ef líf er undir 0 og núllstillir eftir það
    {
        Debug.Log("health er núna" + (health).ToString());
        health -= damage;
        texti.text = "Líf " + health.ToString();
        if (health <= 0)
        {
            SceneManager.LoadScene(2);
            health = 30;
            Kassi.count = 0;//núll stilli stigin 
            texti.text = "Líf " + health.ToString();
        }

    }

    public void SetCountText()//Fall til að gefa upp Stig.
    {
        countText.text = "Stig: " + Kassi.count.ToString();
    }
    public void Sprengin()//Fall til að gera sprengju
    {
        Instantiate(sprenging, transform.position, transform.rotation);
    }


}
